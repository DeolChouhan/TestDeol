﻿using DAL.IDAL;
using DAL.Repository;
using Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.DAL
{
   public class ExecuteInlineQueryDAL : AdoRepository<dynamic>, IExecuteInlineQueryDAL
    {
        #region ExecuteStoreProcedures
        public dynamic ExecuteInlineQuery(SQLModel objSqlModel)
        {
            List<dynamic> list = new List<dynamic>();
            Hashtable param = new Hashtable();
            if (objSqlModel.Params != null)
            {
                foreach (var item in objSqlModel.Params)
                {
                    param.Add(item.Name, item.Value);
                }
            }
            string ConnectionString = Convert.ToString(ConfigurationManager.ConnectionStrings[objSqlModel.Database]);
            DataSet ds = ExecuteInlineQueries(param, objSqlModel.Query, ConnectionString);
            return ds;
        }
        #endregion

    }
}
