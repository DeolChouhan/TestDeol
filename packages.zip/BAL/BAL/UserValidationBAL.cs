﻿using BAL.IBAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;
using DAL.IDAL;

namespace BAL.BAL
{
   public class UserValidationBAL : IUserValidationBAL
    {
        private IUserValidationDAL _objUserDAL;
        public UserValidationBAL(IUserValidationDAL objUserDAL)
        {
            _objUserDAL = objUserDAL;
        }
        public UserModel ValidateUser(UserModel objModel)
        {
           return _objUserDAL.ValidateUser(objModel);
          //throw new NotImplementedException();
        }
    }
}
