﻿using BAL.IBAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;
using DAL.IDAL;
using DAL.DAL;

namespace BAL.BAL
{
    public class ExecuteStoreProcedureBAL : IExecuteStoreProcedureBAL
    {

        private IExecuteStoreProcedureDAL _objExecuteStoreProcedureDAL;
        public ExecuteStoreProcedureBAL(IExecuteStoreProcedureDAL objExecuteStoreProcedureDAL)
        {
            _objExecuteStoreProcedureDAL = objExecuteStoreProcedureDAL;
        }
        public dynamic ExecuteStoreProcedures(SQLModel objSqlModel)
        {
            return _objExecuteStoreProcedureDAL.ExecuteStoreProcedures(objSqlModel);
        }
    }
}
