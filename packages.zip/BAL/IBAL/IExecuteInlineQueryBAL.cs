﻿using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAL.IBAL
{
   public interface IExecuteInlineQueryBAL
    {
        dynamic ExecuteInlineQuery(SQLModel objSqlModel);
    }
}
