﻿using BAL.BAL;
using BAL.IBAL;
using DAL.DAL;
using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AnixReports.Repository
{
    public class UserMasterRepository : IDisposable
    {
        // SECURITY_DBEntities it is your context class
        //  SECURITY_DBEntities context = new SECURITY_DBEntities();
        //This method is used to check and validate the user credentials
        // public UserMaster ValidateUser(string username, string password
        public UserModel ValidateUser(UserModel objUserModel)
        {
           UserValidationDAL objUserBAL = new UserValidationDAL();
            return objUserBAL.ValidateUser(objUserModel);
            //return context.UserMasters.FirstOrDefault(user =>
            //user.UserName.Equals(username, StringComparison.OrdinalIgnoreCase)
            //&& user.UserPassword == password);
        }
        public void Dispose()
        {
           // context.Dispose();
        }
    }
}