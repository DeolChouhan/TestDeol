﻿using AnixReports.Resolver;
using BAL.BAL;
using BAL.IBAL;
using DAL.DAL;
using DAL.IDAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using Unity;

namespace AnixReports
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services
            var container = new UnityContainer();
            container.RegisterType<IUserValidationBAL, UserValidationBAL>();
            container.RegisterType<IUserValidationDAL, UserValidationDAL>();

            container.RegisterType<IExecuteStoreProcedureBAL, ExecuteStoreProcedureBAL>();
            container.RegisterType<IExecuteStoreProcedureDAL, ExecuteStoreProcedureDAL>();

            container.RegisterType<IExecuteInlineQueryBAL, ExecuteInlineQueryBAL>();
            container.RegisterType<IExecuteInlineQueryDAL, ExecuteInlineQueryDAL>();

            config.DependencyResolver = new UnityResolver(container);
            // Web API routes
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );
        }
    }
}
