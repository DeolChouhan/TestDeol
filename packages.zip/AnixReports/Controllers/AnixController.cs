﻿using BAL.IBAL;
using Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Web.Http;

namespace AnixReports.Controllers
{
    public class AnixController : ApiController
    {
        private IExecuteStoreProcedureBAL _objExecuteStoreProcedureBAL;
        private IExecuteInlineQueryBAL _objExecuteInlineQueryBAL;
        public AnixController(IExecuteStoreProcedureBAL objExecuteStoreProcedureBAL, IExecuteInlineQueryBAL objExecuteInlineQueryBAL)
        {
            _objExecuteStoreProcedureBAL = objExecuteStoreProcedureBAL;
            _objExecuteInlineQueryBAL = objExecuteInlineQueryBAL;
        }

        #region Api to execute the Stored Procedure
        [Route("api/ExecuteSQLProcedure")]
        [HttpPost]
        public IHttpActionResult ExecuteSQLProcedure(SQLModel objModel)
        {
            try
            {
                var data = _objExecuteStoreProcedureBAL.ExecuteStoreProcedures(objModel);
                dynamic json = null;
                if (data != null && data.Tables.Count > 0)
                {
                    json = data.Tables[0];
                }
                return Ok(json);
            }
            catch (Exception cc)
            {
               LogError(cc);
            }
            return Ok();

        }
        #endregion

        #region Api to execute the Stored Procedure
        [Route("api/ExecuteSQLProcedureJSON")]
        [HttpPost]
        public IHttpActionResult ExecuteSQLProcedureJSON(SQLModel objModel)
        {
            dynamic json = null;
            try
            {
                var data = _objExecuteStoreProcedureBAL.ExecuteStoreProcedures(objModel);
               // dynamic json = null;
                if (data != null && data.Tables.Count > 0)
                {
                    json = data.Tables[0]; //data.Tables[0].Rows[0];
                    var FCM_Token = Convert.ToString(data.Tables[0].Rows[0]["FCM_Token"]);
                    if (!string.IsNullOrEmpty(FCM_Token) && FCM_Token!="0") {
                        var notification = SendNotificationJSON(FCM_Token,"New Order", "New Order Request For Delivery","");
                    }
                }
                
                return Ok(json);
            }
            catch (Exception cc)
            {
                return Ok(json);
            }
            return Ok();

        }
        #endregion

        private static List<T> ConvertDataTable<T>(DataTable dt)
        {
            List<T> data = new List<T>();
            foreach (DataRow row in dt.Rows)
            {
                T item = GetItem<T>(row);
                data.Add(item);
            }
            return data;
        }
        private static T GetItem<T>(DataRow dr)
        {
            Type temp = typeof(T);
            T obj = Activator.CreateInstance<T>();

            foreach (DataColumn column in dr.Table.Columns)
            {
                foreach (PropertyInfo pro in temp.GetProperties())
                {
                    if (pro.Name == column.ColumnName)
                        pro.SetValue(obj, dr[column.ColumnName], null);
                    else
                        continue;
                }
            }
            return obj;
        }
        #region Api to execute the inline queries
        [Route("api/ExecuteSQLQuery")]
        [HttpPost]
        public IHttpActionResult ExecuteSQLQuery(SQLModel objModel)
        {
            try
            {
                var data = _objExecuteInlineQueryBAL.ExecuteInlineQuery(objModel);
                dynamic json = null;
                if (data != null && data.Tables.Count > 0)
                {
                    json = data.Tables[0];
                }
                else
                {
                    json = "Done";
                }
                return Ok(json);
            }
            catch (Exception cc)
            {
                LogError(cc);
            }
            return Ok();

        }
        #endregion

        private void LogError(Exception ex)
        {
            string message = string.Format("Time: {0}", DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss tt"));
            message += Environment.NewLine;
            message += "-----------------------------------------------------------";
            message += Environment.NewLine;
            message += string.Format("Message: {0}", ex.Message);
            message += Environment.NewLine;
            message += string.Format("StackTrace: {0}", ex.StackTrace);
            message += Environment.NewLine;
            message += string.Format("Source: {0}", ex.Source);
            message += Environment.NewLine;
            message += string.Format("TargetSite: {0}", ex.TargetSite.ToString());
            message += Environment.NewLine;
            message += "-----------------------------------------------------------";
            message += Environment.NewLine;
            string path = System.Web.Hosting.HostingEnvironment.MapPath("~/ErrorLog/ErrorLog.txt");
            using (StreamWriter writer = new StreamWriter(path, true))
            {
                writer.WriteLine(message);
                writer.Close();
            }
        }

        #region Send Push Notification For Android...
        public string SendNotificationJSON(string deviceId, string title, string body, string click_action)
        {
            string SERVER_KEY_TOKEN = ConfigurationManager.AppSettings["Server_Key"];
            var SENDER_ID = ConfigurationManager.AppSettings["Sender_Id"];

            WebRequest tRequest;
            tRequest = WebRequest.Create("https://fcm.googleapis.com/fcm/send");
            tRequest.Method = "post";
            tRequest.ContentType = " application/json";

            tRequest.Headers.Add(string.Format("Authorization: key={0}", SERVER_KEY_TOKEN));
            tRequest.Headers.Add(string.Format("Sender: id={0}", SENDER_ID));

            var a = new
            {
                notification = new
                {
                    title,
                    body,
                    icon = "",
                    click_action,
                    sound = "mySound"
                },
                to = deviceId
            };

            byte[] byteArray = Encoding.UTF8.GetBytes(Newtonsoft.Json.JsonConvert.SerializeObject(a));
            tRequest.ContentLength = byteArray.Length;

            Stream dataStream = tRequest.GetRequestStream();
            dataStream.Write(byteArray, 0, byteArray.Length);
            dataStream.Close();

            WebResponse tResponse = tRequest.GetResponse();
            dataStream = tResponse.GetResponseStream();

            StreamReader tReader = new StreamReader(dataStream);
            string sResponseFromServer = tReader.ReadToEnd();

            tReader.Close();
            dataStream.Close();
            tResponse.Close();

            return sResponseFromServer;
        }

        #endregion
    }
}
